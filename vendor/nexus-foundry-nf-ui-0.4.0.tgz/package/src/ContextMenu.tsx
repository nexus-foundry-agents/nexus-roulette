'use client';

import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/**
 * NF context menu.
 *
 * ⚠️ SCOPED, NEVER GLOBAL. This attaches to ONE surface and suppresses the
 * browser menu only there. Killing right-click across a whole page is a common
 * and hostile move: it takes away Inspect, Back, Open in new tab, spell-check,
 * and the browser's own copy/paste, and users notice immediately. A design tool
 * earns a custom menu on its CANVAS and nowhere else.
 *
 * ⚠️ SHIFT + RIGHT-CLICK ALWAYS YIELDS THE BROWSER'S MENU. That escape hatch is
 * not optional — it is how someone gets to Inspect or Save image on the one
 * surface we took over, and it costs a single line.
 *
 * Shares the `.nf-menu` surface with NfSelect, so a popup looks identical
 * wherever it comes from.
 */

export interface NfMenuItem {
  /** A separator. Everything else is ignored when true. */
  separator?: boolean;
  /** A non-interactive group heading. */
  label?: string;
  id?: string;
  text?: string;
  disabled?: boolean;
  onSelect?: () => void;
}

export interface NfContextMenuProps {
  /** Built when the menu opens, so items can reflect what was right-clicked. */
  items: NfMenuItem[] | (() => NfMenuItem[]);
  ariaLabel: string;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
}

export function NfContextMenu({
  items,
  ariaLabel,
  children,
  className,
  disabled = false,
}: NfContextMenuProps) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState({ x: 0, y: 0 });
  const [built, setBuilt] = useState<NfMenuItem[]>([]);
  const [active, setActive] = useState(-1);
  const [mounted, setMounted] = useState(false);
  const menuRef = useRef<HTMLUListElement>(null);

  useEffect(() => setMounted(true), []);

  const close = useCallback(() => { setOpen(false); setActive(-1); }, []);

  const onContextMenu = (e: React.MouseEvent) => {
    // The escape hatch, before anything else.
    if (disabled || e.shiftKey) return;
    e.preventDefault();
    const list = typeof items === 'function' ? items() : items;
    if (!list.length) return;
    setBuilt(list);
    setPos({ x: e.clientX, y: e.clientY });
    setActive(-1);
    setOpen(true);
  };

  /*
   * Keep the menu on screen. Measured AFTER mount, because the size depends on
   * the items — a menu opened near the bottom right otherwise renders half
   * off-screen, and the items you cannot reach are usually the destructive ones
   * at the end of the list.
   */
  useEffect(() => {
    if (!open) return;
    const el = menuRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const x = Math.min(pos.x, window.innerWidth - r.width - 8);
    const y = Math.min(pos.y, window.innerHeight - r.height - 8);
    if (x !== pos.x || y !== pos.y) setPos({ x: Math.max(8, x), y: Math.max(8, y) });
  }, [open, pos]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      if (!menuRef.current?.contains(e.target as Node)) close();
    };
    const onKey = (e: KeyboardEvent) => {
      const usable = built
        .map((it, i) => ({ it, i }))
        .filter(({ it }) => !it.separator && !it.label && !it.disabled);
      if (e.key === 'Escape') { e.preventDefault(); close(); return; }
      if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        if (!usable.length) return;
        const at = usable.findIndex(({ i }) => i === active);
        const next = e.key === 'ArrowDown'
          ? usable[Math.min(at + 1, usable.length - 1)] ?? usable[0]
          : usable[Math.max(at - 1, 0)] ?? usable[usable.length - 1];
        setActive(next!.i);
        return;
      }
      if (e.key === 'Enter' && active >= 0) {
        e.preventDefault();
        const it = built[active];
        if (it && !it.disabled) { close(); it.onSelect?.(); }
      }
    };
    // Any scroll invalidates the anchor point, so close rather than drift.
    document.addEventListener('pointerdown', onDown, true);
    document.addEventListener('keydown', onKey);
    window.addEventListener('scroll', close, true);
    window.addEventListener('resize', close);
    return () => {
      document.removeEventListener('pointerdown', onDown, true);
      document.removeEventListener('keydown', onKey);
      window.removeEventListener('scroll', close, true);
      window.removeEventListener('resize', close);
    };
  }, [open, built, active, close]);

  return (
    <>
      <div className={className} onContextMenu={onContextMenu}>
        {children}
      </div>

      {mounted && open &&
        createPortal(
          <ul
            ref={menuRef}
            role="menu"
            aria-label={ariaLabel}
            className="nf-menu"
            style={{ top: pos.y, left: pos.x }}
          >
            {built.map((it, i) => {
              if (it.separator) return <li key={`s${i}`} className="nf-menu__sep" role="separator" />;
              if (it.label) return <li key={`l${i}`} className="nf-menu__label" role="presentation">{it.label}</li>;
              return (
                <li
                  key={it.id ?? `i${i}`}
                  role="menuitem"
                  aria-disabled={it.disabled || undefined}
                  data-active={i === active}
                  data-disabled={it.disabled || undefined}
                  className="nf-menu__item"
                  onPointerEnter={() => !it.disabled && setActive(i)}
                  onClick={() => {
                    if (it.disabled) return;
                    close();
                    it.onSelect?.();
                  }}
                >
                  <span>{it.text}</span>
                </li>
              );
            })}
          </ul>,
          document.body,
        )}
    </>
  );
}

export default NfContextMenu;
