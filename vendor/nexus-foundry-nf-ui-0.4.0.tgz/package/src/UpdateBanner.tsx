'use client';

import { useEffect, useState } from 'react';
import { useDeployedBuild, type DeployedBuild, type DeployedBuildOptions } from './useDeployedBuild';

/**
 * A NEW BUILD IS ON THE SERVER; THIS TAB IS RUNNING AN OLDER ONE.
 *
 * Operator, 2026-09-02, relayed by Spark (#9932): every Nexus Foundry product
 * gets "a cue to refresh the page, and an info dot that tells us the full what's
 * in the update every time we have an update."
 *
 * Behaviour and reasoning are Spark's, kept rather than re-argued. What this
 * version adds is portability: it takes `buildId` and `manifestUrl` instead of
 * reaching for one app's build constant, and it styles through nf-ui tokens
 * instead of a host app's CSS variables — the two things that stopped his from
 * being liftable.
 *
 * ⚠️ IT OFFERS A RELOAD, IT DOES NOT PERFORM ONE. Somebody may be part-way
 * through entering a credential, and a page that reloaded itself would throw
 * that away to save them a click. "Later" hides THIS version only; the next
 * deploy raises it again, because what is being announced is new each time.
 *
 * ⚠️ THE ONE LINE IS THE DEPLOYED COMMIT'S SUBJECT, NOT A LABEL WRITTEN HERE.
 * It arrives with the manifest, because this tab is running the OLD build and
 * cannot describe the new one from anything it was compiled with. Anything baked
 * in would describe the version the user ALREADY HAS — the single version it is
 * useless to describe in an "update available" banner. Easy to get backwards,
 * and impossible to notice afterwards.
 *
 * ⚠️ AND THE DESCRIPTION IS THE COMMIT MESSAGE, not a hand-maintained changelog.
 * A curated file is a second place to update, and the second place is the one
 * that gets forgotten — after which the banner confidently announces the
 * PREVIOUS deploy. A commit message cannot drift from what shipped because it
 * IS what shipped.
 */

export interface NfUpdateBannerProps extends DeployedBuildOptions {
  /** Injected in tests. Undefined means "poll for it". */
  deployed?: DeployedBuild | null;
  /**
   * Edge to pin the bar to. TOP by default: a notice placed where the eye does
   * not go is a notice that does not exist, and the bottom edge is where
   * browsers put download bars and cookie tape — company that teaches people to
   * ignore the strip.
   */
  position?: 'top' | 'bottom';
}

export function NfUpdateBanner({
  deployed: injected,
  position = 'top',
  ...opts
}: NfUpdateBannerProps) {
  const polled = useDeployedBuild(opts);
  const deployed = injected !== undefined ? injected : polled;

  const [dismissed, setDismissed] = useState<string | null>(null);
  const [open, setOpen] = useState(false);

  /*
   * ⚠️ THE HOOK RUNS BEFORE THE EARLY RETURN, AND THAT IS NOT A STYLE CHOICE.
   * Hooks must run in the same order on every render; putting this after
   * `if (!deployed) return null` would change the hook count the moment a deploy
   * lands, which React treats as a different component.
   */
  useEffect(() => {
    if (!open) return undefined;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open]);

  if (!deployed || dismissed === deployed.commit) return null;

  const short = deployed.commit.slice(0, 7);
  /*
   * ⚠️ NO INFO DOT WHEN THERE IS NOTHING BEHIND IT. A public manifest withholds
   * the body and the recent log, and a button that opens an empty panel is a
   * dead control — the same shape as a one-option dropdown. Absent beats inert.
   */
  const hasDetail = Boolean(deployed.body) || deployed.recent.length > 0;

  return (
    <>
      <div className="nf-update" role="status" aria-live="polite" data-position={position}>
        <span className="nf-update__subject">A newer version is available</span>
        {/*
          ⚠️ THE HEADLINE IS FIXED AND THE SUBJECT IS THE DESCRIPTION BESIDE IT.
          Operator: "a newer version is available is fine. But we should also see
          a brief description line of what the thing is." Putting the commit
          subject in the headline slot made the banner say something different
          every deploy, so there was nothing constant to recognise — and no room
          left for the description he was asking for.
        */}
        <span className="nf-update__desc" title={deployed.subject}>{deployed.subject}</span>
        <span className="nf-update__commit">{short}</span>

        {hasDetail && (
          <button
            type="button"
            className="nf-update__info"
            aria-label="What is in this update"
            aria-expanded={open}
            onClick={() => setOpen(true)}
          >
            i
          </button>
        )}

        <span className="nf-update__spacer" />

        <button type="button" className="nf-update__reload" onClick={() => location.reload()}>
          Refresh
        </button>
        <button
          type="button"
          className="nf-update__later"
          onClick={() => setDismissed(deployed.commit)}
        >
          Later
        </button>
      </div>

      {open && (
        <div
          className="nf-update__overlay"
          role="dialog"
          aria-modal="true"
          aria-label="What is in this update"
          onClick={(e) => { if (e.target === e.currentTarget) setOpen(false); }}
        >
          <div className="nf-update__panel">
            <h2 className="nf-update__title">{deployed.subject}</h2>
            <div className="nf-update__meta">
              {short}
              {deployed.builtAt ? ` · ${deployed.builtAt}` : ''}
            </div>

            {deployed.body && <p className="nf-update__pre">{deployed.body}</p>}

            {deployed.recent.length > 0 && (
              <>
                <div className="nf-update__label">Recent commits</div>
                <ul className="nf-update__recent">
                  {deployed.recent.map((r) => <li key={r}>{r}</li>)}
                </ul>
              </>
            )}

            <div className="nf-update__actions">
              <button type="button" className="nf-update__reload" onClick={() => location.reload()}>
                Refresh now
              </button>
              <button type="button" className="nf-update__later" onClick={() => setOpen(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default NfUpdateBanner;
