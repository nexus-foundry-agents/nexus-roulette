'use client';

/**
 * NF button.
 *
 * ⚠️ THE CLASSES IN nf-ui.css ARE THE REAL INTERFACE; this is a convenience for
 * React consumers. A button gets rendered by plain HTML, by an anchor, by a form
 * submit and by markup older than any framework — so the styling has to be
 * reachable without importing anything, or those surfaces silently look like
 * someone else's product.
 */

export type NfButtonVariant = 'default' | 'primary' | 'ghost' | 'danger';
export type NfButtonSize = 'sm' | 'md' | 'lg' | 'icon';

export interface NfButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: NfButtonVariant;
  size?: NfButtonSize;
  block?: boolean;
  /** Shows a spinner and disables the button. */
  busy?: boolean;
}

export function NfButton({
  variant = 'default',
  size = 'md',
  block = false,
  busy = false,
  disabled,
  className,
  children,
  ...rest
}: NfButtonProps) {
  const classes = [
    'nf-btn',
    variant !== 'default' ? `nf-btn--${variant}` : '',
    size !== 'md' ? `nf-btn--${size}` : '',
    block ? 'nf-btn--block' : '',
    className ?? '',
  ].filter(Boolean).join(' ');

  return (
    <button
      // `type` defaults to "submit" inside a form, which turns an ordinary
      // button into an accidental form submission. Explicit unless overridden.
      type="button"
      className={classes}
      disabled={disabled || busy}
      // Announced as busy rather than only looking busy.
      aria-busy={busy || undefined}
      {...rest}
    >
      {busy && <span className="nf-spinner" aria-hidden="true" />}
      {children}
    </button>
  );
}

export default NfButton;
