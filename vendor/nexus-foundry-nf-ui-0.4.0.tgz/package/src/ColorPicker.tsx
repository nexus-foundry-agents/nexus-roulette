'use client';

import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/**
 * NF colour picker — swatch trigger, popover with a saturation/value field, a
 * hue slider, presets and a hex box.
 *
 * ⚠️ NOT `<input type="color">`. That opens the OPERATING SYSTEM's colour dialog:
 * a separate window, unstyleable, wildly different on Windows and macOS, and on
 * a design surface it covers the very artwork you are picking a colour against.
 * Same reason the select is here — the browser hands off to the OS and the app
 * loses the ability to look like itself.
 *
 * ⚠️ AND IT SHOWS THE COLOUR AGAINST THE THING IT WILL SIT ON. A colour chosen
 * against a grey dialog is chosen blind; the picker stays inline, over the card.
 */

export interface NfColorPickerProps {
  /** Current colour as #rrggbb, or null for "automatic". */
  value: string | null;
  onChange: (hex: string | null) => void;
  presets?: readonly string[];
  /** Offer an explicit "Automatic" choice that yields null. */
  allowAuto?: boolean;
  autoLabel?: string;
  ariaLabel: string;
  disabled?: boolean;
}

/* ── colour maths, kept local so the package has no dependencies ─────────── */

function clamp01(n: number) { return Math.min(1, Math.max(0, n)); }

export function hsvToHex(h: number, s: number, v: number): string {
  const c = v * s;
  const x = c * (1 - Math.abs(((h / 60) % 2) - 1));
  const m = v - c;
  const [r, g, b] =
    h < 60 ? [c, x, 0] : h < 120 ? [x, c, 0] : h < 180 ? [0, c, x]
      : h < 240 ? [0, x, c] : h < 300 ? [x, 0, c] : [c, 0, x];
  const to = (n: number) => Math.round((n + m) * 255).toString(16).padStart(2, '0');
  return `#${to(r)}${to(g)}${to(b)}`;
}

export function hexToHsv(hex: string): { h: number; s: number; v: number } {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim());
  if (!m) return { h: 0, s: 0, v: 0 };
  const n = parseInt(m[1]!, 16);
  const r = ((n >> 16) & 255) / 255;
  const g = ((n >> 8) & 255) / 255;
  const b = (n & 255) / 255;
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const d = max - min;
  let h = 0;
  if (d) {
    if (max === r) h = 60 * (((g - b) / d) % 6);
    else if (max === g) h = 60 * ((b - r) / d + 2);
    else h = 60 * ((r - g) / d + 4);
  }
  return { h: (h + 360) % 360, s: max ? d / max : 0, v: max };
}

const DEFAULT_PRESETS = [
  '#1a1712', '#000000', '#4a443c', '#8a8178',
  '#fdfcfa', '#ffffff', '#f4ead6', '#d9c9a3',
  '#7b1e28', '#a8452c', '#c78c30', '#4a6b46',
  '#2f4f6b', '#3f5d8a', '#5a4370', '#7d3f5c',
];

export function NfColorPicker({
  value,
  onChange,
  presets = DEFAULT_PRESETS,
  allowAuto = true,
  autoLabel = 'Automatic',
  ariaLabel,
  disabled = false,
}: NfColorPickerProps) {
  const [open, setOpen] = useState(false);
  const [pos, setPos] = useState<{ top: number; left: number } | null>(null);
  const [mounted, setMounted] = useState(false);
  const [hsv, setHsv] = useState(() => hexToHsv(value ?? '#1a1712'));
  const [hexText, setHexText] = useState(value ?? '');

  const triggerRef = useRef<HTMLButtonElement>(null);
  const popRef = useRef<HTMLDivElement>(null);
  const fieldRef = useRef<HTMLDivElement>(null);
  const dragging = useRef<'field' | 'hue' | null>(null);
  const popId = useId();

  useEffect(() => setMounted(true), []);

  // Track external changes, but NOT while the user is dragging — echoing our own
  // committed value back into the cursor makes it stutter under the pointer.
  useEffect(() => {
    if (dragging.current) return;
    setHsv(hexToHsv(value ?? '#1a1712'));
    setHexText(value ?? '');
  }, [value]);

  useEffect(() => {
    if (!open) return;
    const place = () => {
      const t = triggerRef.current;
      if (!t) return;
      const r = t.getBoundingClientRect();
      const W = 232;
      const H = 268;
      setPos({
        top: r.bottom + 6 + H > window.innerHeight ? Math.max(6, r.top - H - 6) : r.bottom + 6,
        left: Math.min(Math.max(6, r.left), window.innerWidth - W - 6),
      });
    };
    place();
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
    return () => {
      window.removeEventListener('scroll', place, true);
      window.removeEventListener('resize', place);
    };
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (popRef.current?.contains(t) || triggerRef.current?.contains(t)) return;
      setOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { setOpen(false); triggerRef.current?.focus(); }
    };
    document.addEventListener('pointerdown', onDown, true);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('pointerdown', onDown, true);
      document.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const commit = useCallback((h: number, s: number, v: number) => {
    const hex = hsvToHex(h, s, v);
    setHexText(hex);
    onChange(hex);
  }, [onChange]);

  const fromField = useCallback((clientX: number, clientY: number) => {
    const el = fieldRef.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    const s = clamp01((clientX - r.left) / r.width);
    const v = 1 - clamp01((clientY - r.top) / r.height);
    setHsv((cur) => { commit(cur.h, s, v); return { ...cur, s, v }; });
  }, [commit]);

  const fromHue = useCallback((clientX: number, el: HTMLElement) => {
    const r = el.getBoundingClientRect();
    const h = clamp01((clientX - r.left) / r.width) * 360;
    setHsv((cur) => { commit(h, cur.s, cur.v); return { ...cur, h }; });
  }, [commit]);

  // Pointer capture on the surfaces, so a drag that leaves the popover keeps
  // tracking — releasing outside is how people actually pick the extremes.
  useEffect(() => {
    if (!dragging.current) return;
    const move = (e: PointerEvent) => {
      if (dragging.current === 'field') fromField(e.clientX, e.clientY);
    };
    const up = () => { dragging.current = null; };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
    return () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
  });

  const shown = value ?? null;

  return (
    <div className="nf-cp">
      <button
        ref={triggerRef}
        type="button"
        className="nf-cp__trigger"
        aria-label={ariaLabel}
        aria-haspopup="dialog"
        aria-expanded={open}
        aria-controls={open ? popId : undefined}
        disabled={disabled}
        onClick={() => setOpen((o) => !o)}
      >
        <span
          className="nf-cp__chip"
          data-auto={shown === null}
          style={shown ? { background: shown } : undefined}
        />
      </button>

      {mounted && open && pos &&
        createPortal(
          <div
            ref={popRef}
            id={popId}
            role="dialog"
            aria-label={ariaLabel}
            className="nf-cp__pop"
            style={{ top: pos.top, left: pos.left }}
          >
            <div
              ref={fieldRef}
              className="nf-cp__field"
              style={{ ['--hue' as string]: hsvToHex(hsv.h, 1, 1) }}
              onPointerDown={(e) => {
                dragging.current = 'field';
                (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
                fromField(e.clientX, e.clientY);
              }}
            >
              <span
                className="nf-cp__cursor"
                style={{ left: `${hsv.s * 100}%`, top: `${(1 - hsv.v) * 100}%` }}
              />
            </div>

            <div
              className="nf-cp__hue"
              onPointerDown={(e) => { dragging.current = 'hue'; fromHue(e.clientX, e.currentTarget); }}
              onPointerMove={(e) => { if (dragging.current === 'hue') fromHue(e.clientX, e.currentTarget); }}
              onPointerUp={() => { dragging.current = null; }}
            >
              <span className="nf-cp__hue-knob" style={{ left: `${(hsv.h / 360) * 100}%` }} />
            </div>

            <div className="nf-cp__presets">
              {presets.map((p) => (
                <button
                  key={p}
                  type="button"
                  className="nf-cp__preset"
                  style={{ background: p }}
                  aria-label={p}
                  aria-pressed={value?.toLowerCase() === p.toLowerCase()}
                  onClick={() => { setHsv(hexToHsv(p)); setHexText(p); onChange(p); }}
                />
              ))}
            </div>

            <div className="nf-cp__row">
              <input
                className="nf-cp__hex"
                value={hexText}
                spellCheck={false}
                aria-label="Hex colour"
                placeholder="#000000"
                onChange={(e) => {
                  const t = e.target.value;
                  setHexText(t);
                  // Only commit a COMPLETE value: committing every keystroke
                  // makes "#ff0000" flash through red-ish nonsense on the card.
                  if (/^#?[0-9a-f]{6}$/i.test(t.trim())) {
                    const hex = t.trim().startsWith('#') ? t.trim() : `#${t.trim()}`;
                    setHsv(hexToHsv(hex));
                    onChange(hex.toLowerCase());
                  }
                }}
              />
              {allowAuto && (
                <button
                  type="button"
                  className="nf-cp__auto"
                  aria-pressed={value === null}
                  onClick={() => { onChange(null); setHexText(''); }}
                >
                  {autoLabel}
                </button>
              )}
            </div>
          </div>,
          document.body,
        )}
    </div>
  );
}

export default NfColorPicker;
