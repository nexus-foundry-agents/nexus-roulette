'use client';

import { useEffect, useState } from 'react';

/**
 * IS THE SERVER SERVING A NEWER BUILD THAN THE ONE THIS TAB IS RUNNING?
 *
 * ── LIFTED, NOT REINVENTED ────────────────────────────────────────────────────
 *
 * The mechanism and most of the reasoning below are Spark's (#9932), who in turn
 * lifted them from casino-monopoly-live rather than designing a second one. The
 * operator asked for the SAME thing across every Nexus Foundry product, and a
 * second design that merely resembles the first is exactly the drift he was
 * complaining about. My part is the SEAM, not the mechanism.
 *
 * ── ⚠️ THE CACHE IS THE WHOLE PROBLEM, AND IT FAILS SILENTLY ──────────────────
 *
 * A poll the browser answers from its own cache compares the running build
 * against a copy of ITSELF, forever. The banner never appears — and a banner
 * that never appears is indistinguishable from one with nothing to say, so
 * nobody ever finds out. Every poll therefore carries BOTH `cache: 'no-store'`
 * AND a unique query string: the header for the browser, the query for anything
 * in front of it that ignores headers.
 *
 * (I hit the same class today from the other side: a Next.js page shipped with
 * `s-maxage=31536000` served a stale document for hours and made a deployed fix
 * look unshipped. Same failure, same invisibility.)
 *
 * ── WHAT IT WILL NOT DO ───────────────────────────────────────────────────────
 *
 * It never reloads the page — somebody may be part-way through entering a
 * credential, and a tab that reloaded itself would throw that away to save a
 * click. And it stays SILENT when it cannot tell: an unknown build id or a
 * failed fetch produces nothing, because a false "update available" trains
 * people to ignore the real one.
 */

export interface DeployedBuild {
  readonly commit: string;
  /** One line for the banner. Always present; callers fall back to a sentence. */
  readonly subject: string;
  /** The rest of that commit message. Empty when there was no body. */
  readonly body: string;
  /** "<short sha> <subject>" for recent commits, newest first. */
  readonly recent: readonly string[];
  readonly builtAt?: string;
}

export interface DeployedBuildOptions {
  /**
   * The commit THIS bundle was built from, or null when it cannot be told.
   *
   * ⚠️ THE SEAM LIVES HERE, and it is the one thing that genuinely differs per
   * app: monopoly reads a Vite define, nexus-foundry a Next `env` constant, and
   * a third will do something else again. The library must not guess at a
   * variable name — a second source for "which build is running" would
   * eventually disagree with the first, inside the component whose entire job
   * is answering that question.
   *
   * null disables the check entirely: a build with no stamp shows no banner,
   * because silence beats a guess.
   */
  buildId: string | null;
  /** Where the manifest lives. `/release.json`, `/module.json`, whatever. */
  manifestUrl: string;
  /** The manifest is cached upstream; asking faster than that buys nothing. */
  pollMs?: number;
}

export const DEFAULT_POLL_MS = 60_000;

/**
 * Read the build the server is serving right now, and what changed in it.
 *
 * Exported for its test: the cache-busting is the part that has to be right, and
 * the only way to check it is to look at the request that was actually made.
 */
export async function fetchDeployedBuild(
  manifestUrl: string,
  fetcher: typeof fetch = fetch,
  now: () => number = Date.now,
): Promise<DeployedBuild | null> {
  try {
    const sep = manifestUrl.includes('?') ? '&' : '?';
    const res = await fetcher(`${manifestUrl}${sep}at=${now()}`, {
      cache: 'no-store',
      headers: { accept: 'application/json' },
    });
    if (!res.ok) return null;
    const m = (await res.json()) as Record<string, unknown>;
    const commit = m?.commit;
    if (typeof commit !== 'string' || !commit) return null;

    /*
     * ⚠️ THE NOTES ARE OPTIONAL AND THEIR ABSENCE IS NOT A FAILURE. A build
     * deployed before this file existed still needs to raise the banner.
     * Refusing the whole manifest over a missing description would turn a
     * cosmetic gap into a SILENT UPDATE — the one outcome this exists to stop.
     */
    const text = (v: unknown) => (typeof v === 'string' ? v : '');
    return {
      commit,
      subject: text(m.subject) || 'A newer build is deployed.',
      body: text(m.body),
      recent: Array.isArray(m.recent)
        ? (m.recent as unknown[]).filter((r): r is string => typeof r === 'string')
        : [],
      ...(text(m.builtAt) ? { builtAt: text(m.builtAt) } : {}),
    };
  } catch {
    // Offline, blocked, mid-deploy — all silent. A false alarm is worse than none.
    return null;
  }
}

/** The deployed build, once it is known to DIFFER from this tab's. */
export function useDeployedBuild({
  buildId,
  manifestUrl,
  pollMs = DEFAULT_POLL_MS,
}: DeployedBuildOptions): DeployedBuild | null {
  const [newer, setNewer] = useState<DeployedBuild | null>(null);

  useEffect(() => {
    if (!buildId) return undefined;
    let live = true;

    const check = async () => {
      const deployed = await fetchDeployedBuild(manifestUrl);
      if (!live || deployed === null) return;
      /*
       * ⚠️ COMPARED AGAINST THE BAKED-IN COMMIT, NEVER AGAINST THE LAST POLL.
       * Comparing consecutive polls would announce an update once and then fall
       * silent, so a tab left open across two deploys shows the banner for the
       * first and hides it again on the second.
       */
      setNewer(deployed.commit === buildId ? null : deployed);
    };

    void check();
    const timer = setInterval(() => void check(), pollMs);
    // Returning to the tab is when the answer matters, and also when a throttled
    // background interval may have stopped firing at all.
    const onVisible = () => {
      if (document.visibilityState === 'visible') void check();
    };
    document.addEventListener('visibilitychange', onVisible);

    return () => {
      live = false;
      clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [buildId, manifestUrl, pollMs]);

  return newer;
}
