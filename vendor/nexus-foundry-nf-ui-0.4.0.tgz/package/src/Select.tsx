'use client';

import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

/**
 * NF Select — a listbox that replaces the native `<select>`.
 *
 * ⚠️ IT EXISTS BECAUSE A NATIVE SELECT'S OPTION LIST CANNOT BE STYLED. The popup
 * is drawn by the operating system, outside the page, so no CSS reaches it: on
 * Windows that means a white sheet with a system-blue highlight in the middle of
 * a dark app, with text you cannot read. This is not a preference — it is the
 * one control the browser refuses to let a design system own.
 *
 * ⚠️ AND REPLACING IT MEANS OWNING WHAT IT GAVE US FOR FREE. A div with a click
 * handler looks finished and is not a select. Everything below is a behaviour
 * the native control had that a naive replacement silently drops:
 *
 *   role/aria-activedescendant   screen readers announce it as a listbox
 *   Enter / Space / Alt+Down     open from the keyboard
 *   Up / Down                    move the ACTIVE option, not the value
 *   Home / End                   jump to first/last
 *   Escape                       close, restore focus, keep the old value
 *   type-ahead                   "ma" jumps to March; resets after ~600ms
 *   click outside / scroll away  close
 *   focus return                 focus goes back to the trigger, always
 *
 * ACTIVE vs SELECTED is the distinction most custom selects lose: arrowing
 * changes which option is highlighted, NOT the value. The value changes on
 * commit. Collapsing them means a user cannot look without choosing.
 */

export interface NfOption<T extends string = string> {
  value: T;
  label: string;
  disabled?: boolean;
}

export interface NfSelectProps<T extends string = string> {
  value: T;
  options: readonly NfOption<T>[];
  onChange: (value: T) => void;
  /** Shown when nothing matches `value`. */
  placeholder?: string;
  disabled?: boolean;
  /** Accessible name. Required — an unlabelled listbox is unusable by screen reader. */
  ariaLabel: string;
  className?: string;
  id?: string;
}

const TYPEAHEAD_MS = 600;

export function NfSelect<T extends string = string>({
  value,
  options,
  onChange,
  placeholder = 'Select…',
  disabled = false,
  ariaLabel,
  className,
  id,
}: NfSelectProps<T>) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const [rect, setRect] = useState<{ top: number; left: number; width: number } | null>(null);
  const [mounted, setMounted] = useState(false);

  const triggerRef = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLUListElement>(null);
  const typed = useRef({ buf: '', at: 0 });
  const listId = useId();

  useEffect(() => setMounted(true), []);

  const selectedIndex = options.findIndex((o) => o.value === value);
  const selected = selectedIndex >= 0 ? options[selectedIndex] : undefined;

  /**
   * Position the popup. useLayoutEffect so it is placed BEFORE paint — with a
   * plain effect the menu renders at 0,0 for a frame and visibly jumps.
   */
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      const t = triggerRef.current;
      if (!t) return;
      const r = t.getBoundingClientRect();
      const below = window.innerHeight - r.bottom;
      const wanted = Math.min(288, options.length * 34 + 8);
      // Flip above when there is not room below and there IS room above.
      const flip = below < wanted && r.top > below;
      setRect({
        top: flip ? Math.max(4, r.top - wanted - 4) : r.bottom + 4,
        left: r.left,
        width: r.width,
      });
    };
    place();
    // Reposition on scroll ANYWHERE (capture), because the trigger commonly
    // lives inside a scrolling panel, not the document.
    window.addEventListener('scroll', place, true);
    window.addEventListener('resize', place);
    return () => {
      window.removeEventListener('scroll', place, true);
      window.removeEventListener('resize', place);
    };
  }, [open, options.length]);

  const close = useCallback((restoreFocus = true) => {
    setOpen(false);
    if (restoreFocus) triggerRef.current?.focus();
  }, []);

  const commit = useCallback(
    (i: number) => {
      const opt = options[i];
      if (!opt || opt.disabled) return;
      onChange(opt.value);
      close();
    },
    [options, onChange, close],
  );

  const openMenu = useCallback(() => {
    if (disabled) return;
    setActive(selectedIndex >= 0 ? selectedIndex : 0);
    setOpen(true);
  }, [disabled, selectedIndex]);

  /** Move the active option, skipping disabled ones, without wrapping past the ends. */
  const move = useCallback(
    (from: number, dir: 1 | -1) => {
      let i = from;
      for (let n = 0; n < options.length; n += 1) {
        i += dir;
        if (i < 0 || i >= options.length) return from;
        if (!options[i]?.disabled) return i;
      }
      return from;
    },
    [options],
  );

  function onKeyDown(e: React.KeyboardEvent) {
    if (!open) {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        openMenu();
      }
      return;
    }

    switch (e.key) {
      case 'Escape':
        e.preventDefault();
        close();
        return;
      case 'Tab':
        // Tab commits nothing and closes — matching the native control.
        close(false);
        return;
      case 'ArrowDown':
        e.preventDefault();
        setActive((a) => move(a, 1));
        return;
      case 'ArrowUp':
        e.preventDefault();
        setActive((a) => move(a, -1));
        return;
      case 'Home':
        e.preventDefault();
        setActive(options.findIndex((o) => !o.disabled));
        return;
      case 'End': {
        e.preventDefault();
        for (let i = options.length - 1; i >= 0; i -= 1) {
          if (!options[i]?.disabled) { setActive(i); break; }
        }
        return;
      }
      case 'Enter':
      case ' ':
        e.preventDefault();
        commit(active);
        return;
      default:
        break;
    }

    // Type-ahead. Single printable characters only, so it never eats a shortcut.
    if (e.key.length === 1 && !e.metaKey && !e.ctrlKey && !e.altKey) {
      const now = Date.now();
      typed.current.buf = now - typed.current.at > TYPEAHEAD_MS ? e.key : typed.current.buf + e.key;
      typed.current.at = now;
      const q = typed.current.buf.toLowerCase();
      const hit = options.findIndex((o) => !o.disabled && o.label.toLowerCase().startsWith(q));
      if (hit >= 0) setActive(hit);
    }
  }

  // Keep the active option scrolled into view while arrowing.
  useEffect(() => {
    if (!open) return;
    menuRef.current
      ?.querySelector<HTMLElement>(`[data-index="${active}"]`)
      ?.scrollIntoView({ block: 'nearest' });
  }, [active, open]);

  // Close on an outside pointer press. `pointerdown`, not `click`: a click fires
  // after mouseup, so a drag that starts outside would leave the menu open.
  useEffect(() => {
    if (!open) return;
    const onDown = (e: PointerEvent) => {
      const t = e.target as Node;
      if (menuRef.current?.contains(t) || triggerRef.current?.contains(t)) return;
      setOpen(false);
    };
    document.addEventListener('pointerdown', onDown, true);
    return () => document.removeEventListener('pointerdown', onDown, true);
  }, [open]);

  return (
    <div className={`nf-select${className ? ` ${className}` : ''}`}>
      <button
        ref={triggerRef}
        id={id}
        type="button"
        className="nf-select__trigger"
        disabled={disabled}
        aria-label={ariaLabel}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-controls={open ? listId : undefined}
        aria-activedescendant={open ? `${listId}-${active}` : undefined}
        onClick={() => (open ? close() : openMenu())}
        onKeyDown={onKeyDown}
      >
        {/*
          ⚠️ WIDTH IS RESERVED FOR THE LONGEST OPTION, ALWAYS.

          MEASURED 2026-09-02: with the trigger sized to its CURRENT label, the
          control's width changed every time the value changed — "Body" is
          narrower than "Title" — so the control moved sideways, and the popup,
          correctly anchored to it, moved with it. The menu's top was identical
          to the pixel every time; only `left` drifted (476 -> 471 -> 466).

          A control that resizes when you use it makes the next click a moving
          target, and it reads as the menu "shuffling around" even though the
          menu is innocent.

          Every label is rendered into the same grid cell, all but the live one
          hidden, so the box is as wide as its widest possible content and never
          changes. `visibility: hidden` rather than `display: none` because a
          removed element contributes no width, which is the whole point.
        */}
        <span className="nf-select__value-wrap">
          {options.map((o) => (
            <span key={o.value} className="nf-select__sizer" aria-hidden="true">{o.label}</span>
          ))}
          <span className="nf-select__sizer" aria-hidden="true">{placeholder}</span>
          <span className="nf-select__value" data-placeholder={!selected}>
            {selected ? selected.label : placeholder}
          </span>
        </span>
        <span className="nf-select__caret" aria-hidden="true" />
      </button>

      {mounted && open && rect &&
        createPortal(
          <ul
            ref={menuRef}
            id={listId}
            role="listbox"
            aria-label={ariaLabel}
            className="nf-menu"
            style={{ top: rect.top, left: rect.left, minWidth: rect.width }}
            onKeyDown={onKeyDown}
          >
            {options.map((o, i) => (
              <li
                key={o.value}
                id={`${listId}-${i}`}
                role="option"
                aria-selected={o.value === value}
                aria-disabled={o.disabled || undefined}
                data-index={i}
                data-active={i === active}
                data-selected={o.value === value}
                data-disabled={o.disabled || undefined}
                className="nf-menu__item"
                onPointerEnter={() => !o.disabled && setActive(i)}
                onClick={() => commit(i)}
              >
                <span>{o.label}</span>
                {o.value === value && <span className="nf-menu__check" aria-hidden="true">●</span>}
              </li>
            ))}
          </ul>,
          document.body,
        )}
    </div>
  );
}

export default NfSelect;
