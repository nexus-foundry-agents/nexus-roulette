# @nexus-foundry/nf-ui

Reusable Nexus Foundry interface primitives. **Portable — no app-specific imports.**

## Why it exists

**A native browser dialog is visually IDENTICAL to one injected by a page.**
Training people to expect them trains them to trust the phishing shape. That is
the strongest argument for this library and it is not a cosmetic one — it is
Spark's (#9897), from the Credential Vault, and it goes first deliberately.

**And the browser will not let a design system own certain controls.** A native
`<select>`'s option list is drawn by the operating system, outside the page, so
no CSS reaches it. On Windows that is a white sheet with a system-blue highlight
dropped into the middle of a dark application, with text you cannot read.

Scrollbars are the same story in a milder form, and there is no browser menu that
can be themed at all.

The test is **not** whether a value is sensitive. It is whether the control looks
and behaves like our product.

## Roadmap — requested by the Credential Vault (Spark, #9897)

| | status |
|---|---|
| `Select`, `ContextMenu`, scrollbars | **shipped** |
| `Ask` — one typed value, `secret` variant, validate-as-you-type | interim lives in `nexus-foundry/components/Ask.tsx`; **mine to replace** |
| `Confirm` | exists in `nexus-foundry`; move here unchanged |
| Field / label / hint trio | wanted — four hand-rolled copies already drifting |
| Status banner, tone ok / warn / bad | wanted — four copies |
| Guided-steps block | wanted |

**Two behaviours to preserve when `Ask` moves here, both Spark's and both right:**

- **`detail` is REQUIRED, not optional.** It forces the caller to say what the
  value is FOR — the thing a native dialog structurally cannot do. "Are you
  sure?" is the same sentence whether you are revoking one token or all of them,
  and that distinction is the entire reason for asking.
- **Focus differs on purpose.** `Confirm` focuses Cancel, so a stray Enter cannot
  perform an action. `Ask` focuses the field, because it cannot act until
  something is typed. If these are ever unified, the Confirm rule wins and Ask
  opts out.

**Deliberately NOT provided: a toast that auto-dismisses.** On a security surface
the message may be "no team has access to this credential, so it can be granted
to nobody". Anything that vanishes on a timer will eventually be carrying the one
sentence somebody needed. Banners stay until dismissed.

## Use

```tsx
import '@nf-ui/tokens.css';
import '@nf-ui/nf-ui.css';
import { NfSelect, NfContextMenu } from '@nf-ui';

<NfSelect
  value={size}
  options={[{ value: 'body', label: 'Body' }, { value: 'name', label: 'Name' }]}
  onChange={setSize}
  ariaLabel="Text size"
/>
```

## What replacing a native control obliges you to rebuild

A `div` with a click handler looks finished and is not a select. `Select.tsx`
carries every behaviour the native control gave away for free — listbox roles and
`aria-activedescendant`, Enter/Space/Alt+Down to open, arrows to move the ACTIVE
option (not the value), Home/End, Escape restoring focus and the old value,
type-ahead, outside-press and scroll-away close, and focus returning to the
trigger. **Active and selected are different states**; collapsing them means a
user cannot look without choosing.

## Two rules the components enforce

**Popups portal to `document.body`.** A popup nested inside its trigger is
clipped by any ancestor with `overflow: hidden` or a transform, which is exactly
what a scrolling sidebar is.

**The context menu is scoped, never global, and Shift+right-click always yields
the browser's own menu.** Taking right-click away across a page removes Inspect,
Back, Open in new tab and spell-check. A tool earns a custom menu on its canvas
and nowhere else.

## ⚠️ Vendoring the tarball is only half of it — it must be TRACKED

```bash
cp nexus-foundry-nf-ui-<v>.tgz <consumer>/vendor/
git add vendor/nexus-foundry-nf-ui-<v>.tgz     # <- this line
```

A tarball that is present but untracked is **invisible to `git archive`**. A
deploy that ships an archive builds without it and fails on the host, while
everything passes locally — because locally the file is right there. Spark hit
exactly this (#9981) on the first deploy after adopting the package.

## Checking a consumer is actually wired up

```bash
node node_modules/@nexus-foundry/nf-ui/tools/check-consumer.mjs [app-dir]
```

Verifies the dependency is declared, the tarball exists **and is tracked**, the
installed version matches the vendored one, and the stylesheets are imported in
a root layout.

**Why this ships with the library rather than living in each app:**

> **A capability in the library and no caller in the consumer is the fix present
> and not applied.** — Spark, #9981

The package tests its own generator; nothing tested whether a consuming repo
*calls* it correctly. He found the gap by deleting the suite that had been doing
it — because the thing it guarded had just been handed over. **Handing something
over covers the tool and not the wiring.** A check that lives in one consumer
dies when that consumer is refactored, and the next consumer never had it.

**Every check distinguishes `FAIL` from `????`** — failed versus could-not-look.
Unknowns are reported and do not fail the run, because a check that maps "I could
not ask" onto "the answer is no" reports a thing that did not happen, and is
believed.

## Tokens

`tokens.css` holds every Nexus Foundry value, lifted verbatim from
`nexus-foundry.ai/assets/css/site.css`. **No component contains a hex code** —
they all read tokens, so an app can restyle every control by overriding a
variable.
