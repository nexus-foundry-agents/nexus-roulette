#!/usr/bin/env node
/**
 * WHAT CHANGED IN THIS BUILD — read from git, written where the deployed app can serve it.
 *
 *   node build-release-notes.mjs <output-dir> [<ref>] [--public]
 *
 * Operator, 2026-09-02: bring the Monopoly Live update banner to every Nexus Foundry product — a
 * cue to refresh, and an info dot carrying the full description of what changed.
 *
 * ── THE DESCRIPTION IS THE COMMIT MESSAGE, AND THAT IS THE LOAD-BEARING CHOICE ──
 *
 * Lifted from casino-monopoly-live's scripts/build-module-json.mjs, whose reasoning I am keeping
 * rather than re-deriving: a hand-maintained changelog is a second place to update, and the second
 * place is the one that gets forgotten — after which the banner confidently announces the PREVIOUS
 * deploy. The commit message is already the description, already reviewed, and cannot drift from
 * what shipped because it IS what shipped.
 *
 * ── ⚠️ --public: THE MANIFEST IS SERVED TO WHOEVER CAN REACH THE APP ──
 *
 * Commit bodies describe deploy mechanics, guard architecture, internal message
 * ids and teammate names. On a GATED surface that is fine and useful. On a
 * PUBLIC product it is architecture disclosure to strangers, for no benefit —
 * the person reading an "update available" banner on a public site wants the one
 * line, not the engineering rationale.
 *
 * MEASURED 2026-09-02: cards.nexus-foundry.ai/release.json served 3,428 chars of
 * commit body plus ten commit subjects to anyone who asked. I published that
 * fifteen minutes after writing the generator, and only caught it re-reading
 * Spark's note that his own manifest is gated ON PURPOSE for exactly this.
 *
 * So the DEFAULT stays full (gated apps lose nothing) and `--public` emits
 * commit, builtAt and a GENERIC subject. The choice is explicit at the call
 * site, where somebody can see it, rather than implicit in who serves what.
 *
 * ⚠️ THE SUBJECT IS GENERALISED TOO, AND THAT WAS NOT MY FIRST ANSWER.
 *
 * Spark checked the fix from the edge instead of taking my report (#9949) and
 * pointed out that the anonymous manifest still carried the commit SUBJECT — and
 * that the subject sitting there at that moment was "fix(nf-ui): --public
 * withholds commit bodies". MY SECURITY FIX ANNOUNCED ITSELF BY NAME TO ANYONE
 * WHO ASKED. Subjects are three orders of magnitude smaller than a body and they
 * are not nothing.
 *
 * It is also the better product answer, which is what settles it: someone using
 * a public card studio does not want "fix(nf-ui): --public withholds commit
 * bodies", they want "A newer version is available." The engineering subject was
 * never for them. Withholding it costs the public reader nothing and tells a
 * stranger less.
 *
 * ── ⚠️ IT LIVES IN THE LIBRARY BECAUSE THE GENERATOR AND THE READER MUST AGREE ──
 *
 * This writes the manifest; useDeployedBuild.ts reads it. They share a shape and
 * NOTHING ELSE CHECKS THAT THEY AGREE — a field renamed on one side produces a
 * banner that simply never appears, which is indistinguishable from having
 * nothing to announce. Shipping them in the same package is the cheapest way to
 * make them move together. (Spark's point, #9932, and the reason his test file
 * reads the REAL generated file rather than a fixture.)
 *
 * ── ⚠️ WHY THIS RUNS BEFORE THE ARCHIVE AND NOT INSIDE THE IMAGE BUILD ──
 *
 * Consumers deploy by piping a tar of the working tree over ssh, or by
 * `git archive`, both of which produce a tree with NO .git directory. A generator that ran during `docker build` would find no history and silently emit
 * empty notes — a banner that appears with nothing to say, which is worse than no banner because it
 * teaches people the info dot is empty.
 *
 * So it runs HERE, where git exists, and writes a file that is copied into the build context. The
 * monopoly version notes the same hazard from the other side ("one built by git archive, which has
 * no log to read"); this is that warning acted on.
 */

import { execFileSync } from 'node:child_process';
import { writeFileSync, mkdirSync, existsSync, readFileSync } from 'node:fs';
import path from 'node:path';

const args = process.argv.slice(2);
const isPublic = args.includes('--public');
const positional = args.filter((a) => !a.startsWith('--'));
const outDir = positional[0];
/**
 * ⚠️ WHAT SHIPS IS NOT ALWAYS HEAD, AND THE TOOL HAS TO KNOW THAT.
 *
 * Spark, #9975. Card Studio deploys its WORKING TREE, so HEAD is exactly what
 * ships and the default is right. nexus-foundry archives `origin/$BRANCH`, which
 * is not necessarily whatever happens to be checked out — so run this there
 * against HEAD and the manifest confidently describes a build nobody deployed.
 *
 * He had already solved it in his own deploy script, with a detached worktree of
 * the deploying sha so that HEAD meant the right thing. That works, and he was
 * about to keep a FORKED generator with a ref argument instead, which he caught
 * and rejected as two generators for one manifest.
 *
 * Taking the argument is the better end state, and not only because it is
 * smaller than a worktree per deploy: THE KNOWLEDGE THAT "HEAD IS NOT WHAT
 * SHIPS HERE" BELONGS IN THE TOOL, not in one consumer's deploy script where
 * the next repo with the same shape has to rediscover it.
 *
 * HEAD stays the default, so nothing existing changes.
 */
const ref = positional[1] || 'HEAD';
if (!outDir) {
  console.error('usage: node build-release-notes.mjs <output-dir> [<ref>] [--public]');
  process.exit(2);
}

const git = (args) => {
  try {
    return execFileSync('git', args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] });
  } catch {
    return '';
  }
};

const commit = git(['rev-parse', '--short', ref]).trim();
if (!commit) {
  // REFUSE rather than emit a file claiming an unknown build. A release.json with no commit would
  // make every tab think it is stale, forever.
  console.error(`not in a git repository, or "${ref}" is unreadable. Refusing to write empty notes.`);
  process.exit(2);
}

const subject = git(['log', '-1', '--format=%s', ref]).trim();
const rawBody = git(['log', '-1', '--format=%b', ref]).trim();

/*
  TRAILERS ARE ADDRESSED TO THE REPOSITORY, NOT TO THE PERSON READING A BANNER. Dropped here rather
  than at render time so the served artefact is itself the readable thing — a consumer that renders
  it raw gets the right result without knowing to strip anything.
*/
const body = rawBody
  .split(/\r?\n/)
  .filter((line) => !/^[A-Za-z-]+-[Bb]y:\s/.test(line))
  .filter((line) => !/^Claude-Session:\s/.test(line))
  .join('\n')
  .trim();

/**
 * ⚠️ --public MEANS WITHHOLD, FULL STOP. NO CLEVERNESS.
 *
 * I tried to keep a description by stripping the conventional-commit prefix, so
 * "feat(studio): transform handles" would read "Transform handles". THE TEST
 * CAUGHT THAT IT WITHHOLDS NOTHING: this repo's own subjects carry no prefix, so
 * the "public" subject came back byte-identical to the real one.
 *
 * The deeper reason it could never work: THE SUBJECT IS SIMULTANEOUSLY THE
 * DESCRIPTION SOMEBODY WANTS AND THE THING THAT LEAKS. One string cannot be both
 * withheld and informative, and a transform that sometimes withholds is worse
 * than one that never does, because you cannot tell which case you are in.
 *
 * So a surface either wants the real notes or it does not:
 *
 *   gated / internal   omit --public   full subject, body and recent log
 *   truly public       --public        a fixed line and nothing else
 *
 * An app that wants a human description on a public surface needs a HUMAN
 * SENTENCE written for users, which is a different artefact from a commit
 * message and belongs to whoever owns the product copy.
 */
function publicSubject() {
  return 'A newer version is available.';
}

const recent = git(['log', '-10', '--format=%h %s', ref])
  .split(/\r?\n/)
  .map((l) => l.trim())
  .filter(Boolean);

const notes = {
  commit,
  builtAt: new Date().toISOString(),
  /*
    ALWAYS PRESENT, because the banner shows this line and an empty one would announce an update
    while saying nothing about it. A plain sentence is a poor description and an honest one.
  */
  subject: isPublic ? publicSubject(subject) : (subject || 'A newer build is deployed.'),
  /*
    On a public surface the body and the recent log are withheld. The banner
    still works — it needs `commit` to fire and `subject` to say something — and
    the reader treats their absence as normal rather than as a failure.
  */
  body: isPublic ? '' : body,
  recent: isPublic ? [] : recent,
};

/*
 * ⚠️ REGENERATING THE MANIFEST WITHOUT REBUILDING CREATES A BANNER THAT CAN
 * NEVER BE DISMISSED. MEASURED 2026-09-02, by doing it.
 *
 * The manifest names a commit; the BUNDLE has one inlined. The banner compares
 * them. Run this generator on its own after a build and the two disagree
 * permanently — so the banner appears, and Refresh cannot clear it, because the
 * mismatch is on the SERVER and reloading fetches the same pair again. The
 * operator hit exactly this and reported "I click refresh, it doesn't actually
 * change."
 *
 * That is the false alarm this component is supposed to avoid, manufactured by
 * its own tooling. So: if a build already exists and was stamped with a
 * DIFFERENT commit, say so loudly. A warning here is cheap; the alternative is a
 * permanent notification nobody can silence, which teaches people to ignore the
 * real one.
 */
try {
  const stamp = path.join(outDir, '..', '.next', 'BUILD_ID');
  const built = existsSync(stamp);
  if (built && existsSync(path.join(outDir, 'release.json'))) {
    const prev = JSON.parse(readFileSync(path.join(outDir, 'release.json'), 'utf8'));
    if (prev.commit && prev.commit !== commit) {
      console.warn(
        `
  ⚠️  A build already exists and the manifest is moving ${prev.commit} -> ${commit}.` +
        `
      REBUILD, or the running bundle keeps the old id and the update banner` +
        `
      appears permanently with no way to dismiss it.
`,
      );
    }
  }
} catch { /* advisory only; never block generating notes */ }

mkdirSync(outDir, { recursive: true });
const file = path.join(outDir, 'release.json');
writeFileSync(file, JSON.stringify(notes, null, 2) + '\n');

console.log(`release notes for ${commit}: ${notes.subject.slice(0, 60)}`);
console.log(
  isPublic
    ? `  PUBLIC: subject generalised, body and recent log withheld · -> ${file}`
    : `  ${recent.length} recent commits · body ${body.length} chars · -> ${file}`,
);
