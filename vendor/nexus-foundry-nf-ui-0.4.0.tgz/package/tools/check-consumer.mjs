#!/usr/bin/env node
/**
 * IS THIS CONSUMER ACTUALLY WIRED TO THE LIBRARY, OR DOES IT ONLY LOOK LIKE IT?
 *
 *   node node_modules/@nexus-foundry/nf-ui/tools/check-consumer.mjs [app-dir]
 *
 * ⚠️ SPARK'S FINDING, #9981, AND IT IS THE GAP THIS PACKAGE HAD:
 *
 *   "A CAPABILITY IN THE LIBRARY AND NO CALLER IN THE CONSUMER IS THE FIX
 *    PRESENT AND NOT APPLIED."
 *
 * The package tests its own generator. NOTHING tested whether a consuming repo
 * CALLS it correctly — and he had just deleted the file that did, because the
 * thing it guarded had been handed to the library. HANDING SOMETHING OVER
 * COVERS THE TOOL AND NOT THE WIRING.
 *
 * So this ships WITH the library, because a check that lives in one consumer
 * dies when that consumer is refactored, and the next consumer never had it.
 *
 * ⚠️ EVERY CHECK DISTINGUISHES "FAILED" FROM "COULD NOT LOOK". Spark had two
 * checks in his first pass that LIED rather than failed: an indexOf matched a
 * phrase inside a COMMENT and reported Dockerfile layer order backwards with a
 * confident wrong explanation, and a catch mapped "I could not ask git" onto
 * "git says no". A check that reports a thing that did not happen is worse than
 * no check, because it is believed.
 */

import { execFileSync } from 'node:child_process';
import { existsSync, readFileSync } from 'node:fs';
import path from 'node:path';

const appDir = path.resolve(process.argv[2] || process.cwd());

const results = [];
const ok = (name, detail) => results.push({ state: 'ok', name, detail });
const bad = (name, detail) => results.push({ state: 'FAIL', name, detail });
/** Not a pass and not a failure. Naming the third state is the whole point. */
const unknown = (name, detail) => results.push({ state: '????', name, detail });

function git(args, cwd) {
  try {
    return { ok: true, out: execFileSync('git', args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim() };
  } catch (e) {
    return { ok: false, err: String(e?.message ?? e) };
  }
}

// ── 1. the dependency is declared, and points somewhere real ────────────────
const pkgPath = path.join(appDir, 'package.json');
if (!existsSync(pkgPath)) {
  console.error(`no package.json at ${appDir}`);
  process.exit(2);
}
const pkg = JSON.parse(readFileSync(pkgPath, 'utf8'));
const spec = pkg.dependencies?.['@nexus-foundry/nf-ui'];

if (!spec) {
  bad('dependency declared', 'no @nexus-foundry/nf-ui in dependencies');
} else if (!spec.startsWith('file:')) {
  ok('dependency declared', `${spec} (not a vendored tarball — check this is intended)`);
} else {
  const tarball = path.resolve(appDir, spec.slice('file:'.length));
  if (!existsSync(tarball)) {
    bad('tarball exists', `${spec} does not resolve to a file`);
  } else {
    ok('tarball exists', path.relative(appDir, tarball));

    /*
     * ⚠️ THE ONE THAT BIT HIM. A vendored tarball that is not TRACKED is
     * invisible to `git archive`, so a deploy that ships an archive builds
     * without it and fails on the box — while everything passes locally,
     * because locally the file is right there.
     */
    const tracked = git(['ls-files', '--error-unmatch', tarball], appDir);
    if (tracked.ok) ok('tarball tracked in git', 'git archive will include it');
    else if (/not a git repository/i.test(tracked.err ?? '')) {
      unknown('tarball tracked in git', 'not a git repository — cannot tell');
    } else {
      bad('tarball tracked in git',
        'UNTRACKED. A deploy using `git archive` ships without it and the build fails on the host.');
    }
  }
}

// ── 2. the installed copy matches the declared one ──────────────────────────
const installed = path.join(appDir, 'node_modules', '@nexus-foundry', 'nf-ui', 'package.json');
if (!existsSync(installed)) {
  bad('installed', 'node_modules/@nexus-foundry/nf-ui is missing — run npm install');
} else {
  const v = JSON.parse(readFileSync(installed, 'utf8')).version;
  const declared = spec?.match(/nf-ui-([0-9.]+)\.tgz$/)?.[1];
  if (!declared) unknown('installed version matches the vendored tarball', `installed ${v}; tarball version not in the filename`);
  else if (declared === v) ok('installed version matches', v);
  else bad('installed version matches',
    `package.json vendors ${declared} but node_modules has ${v} — run npm install`);
}

// ── 3. the stylesheets are actually imported ────────────────────────────────
// A component library whose CSS is never imported renders unstyled, and every
// individual import looks fine in isolation.
const roots = ['app/layout.tsx', 'src/app/layout.tsx', 'pages/_app.tsx', 'src/pages/_app.tsx']
  .map((r) => path.join(appDir, r)).filter(existsSync);
if (!roots.length) {
  unknown('stylesheets imported', 'no recognised root layout — check by hand');
} else {
  const text = roots.map((r) => readFileSync(r, 'utf8')).join('\n');
  const hasTokens = text.includes('nf-ui/src/tokens.css');
  const hasStyles = text.includes('nf-ui/src/nf-ui.css');
  if (hasTokens && hasStyles) ok('stylesheets imported', path.relative(appDir, roots[0]));
  else bad('stylesheets imported',
    `missing ${[!hasTokens && 'tokens.css', !hasStyles && 'nf-ui.css'].filter(Boolean).join(' and ')}`);
}

// ── report ─────────────────────────────────────────────────────────────────
const width = Math.max(...results.map((r) => r.name.length));
for (const r of results) {
  console.log(`  ${r.state.padEnd(5)} ${r.name.padEnd(width)}  ${r.detail}`);
}
const failed = results.filter((r) => r.state === 'FAIL').length;
const unknowns = results.filter((r) => r.state === '????').length;
console.log(
  `\n  ${results.length - failed - unknowns} ok · ${failed} failed · ${unknowns} could not be checked`,
);
// Unknowns do NOT fail the run — they are reported so nobody reads them as passes.
process.exit(failed ? 1 : 0);
